package acc.br.nextpay;

import acc.br.nextpay.controller.TratadorGlobalDeExcecoes;
import acc.br.nextpay.exception.NegocioException;
import acc.br.nextpay.exception.RecursoNaoEncontradoException;
import acc.br.nextpay.exception.SaldoInsuficienteException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

class TratadorGlobalDeExcecoesTest {

    private TratadorGlobalDeExcecoes tratador;

    @BeforeEach
    void setUp() {
        tratador = new TratadorGlobalDeExcecoes();
    }

    @Test
    void deveTratarRecursoNaoEncontrado() {
        RecursoNaoEncontradoException ex = new RecursoNaoEncontradoException("Usuário não existe");

        ResponseEntity<Map<String, String>> resposta = tratador.tratarNaoEncontrado(ex);

        Assertions.assertEquals(HttpStatus.NOT_FOUND, resposta.getStatusCode());
        Assertions.assertEquals("Usuário não existe", resposta.getBody().get("erro"));
    }

    @Test
    void deveTratarSaldoInsuficiente() {
        SaldoInsuficienteException ex = new SaldoInsuficienteException("Sem fundos");

        ResponseEntity<Map<String, String>> resposta = tratador.tratarSaldoInsuficiente(ex);

        Assertions.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, resposta.getStatusCode());
        Assertions.assertEquals("Sem fundos", resposta.getBody().get("erro"));
    }

    @Test
    void deveTratarErroDeNegocio() {
        NegocioException ex = new NegocioException("Regra violada");

        ResponseEntity<Map<String, String>> resposta = tratador.tratarNegocio(ex);

        Assertions.assertEquals(HttpStatus.BAD_REQUEST, resposta.getStatusCode());
        Assertions.assertEquals("Regra violada", resposta.getBody().get("erro"));
    }

    @Test
    void deveTratarErroGenerico() {
        RuntimeException ex = new RuntimeException("Erro catastrófico");

        ResponseEntity<Map<String, String>> resposta = tratador.tratarErroGenerico(ex);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resposta.getStatusCode());
        Assertions.assertEquals("Erro interno. Tente novamente.", resposta.getBody().get("erro"));
    }
}