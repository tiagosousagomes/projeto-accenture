package acc.br.nextpay;

import acc.br.nextpay.config.SecurityConfig;
import acc.br.nextpay.security.JwtFilter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SecurityConfigTest.TestController.class)
@Import(SecurityConfig.class)
class SecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private SecurityConfig securityConfig;

    @MockBean
    private JwtFilter jwtFilter;

    @BeforeEach
    void setup() {

        ReflectionTestUtils.setField(
                securityConfig,
                "allowedOrigins",
                "http://localhost:5173"
        );
    }

    // =========================================================
    // PASSWORD ENCODER
    // =========================================================

    @Test
    void deveRetornarBCryptPasswordEncoder() {

        PasswordEncoder encoder = securityConfig.passwordEncoder();

        Assertions.assertNotNull(encoder);

        Assertions.assertTrue(
                encoder instanceof BCryptPasswordEncoder
        );

        String senha = "123456";

        String hash = encoder.encode(senha);

        Assertions.assertTrue(
                encoder.matches(senha, hash)
        );

        Assertions.assertFalse(
                encoder.matches("senha_errada", hash)
        );
    }

    // =========================================================
    // CORS
    // =========================================================

    @Test
    void deveConfigurarCorsCorretamente() {

        var source = securityConfig.corsConfigurationSource();

        Assertions.assertTrue(
                source instanceof UrlBasedCorsConfigurationSource
        );

        UrlBasedCorsConfigurationSource urlSource =
                (UrlBasedCorsConfigurationSource) source;

        CorsConfiguration config =
                urlSource.getCorsConfigurations().get("/**");

        Assertions.assertNotNull(config);

        List<String> origins = config.getAllowedOrigins();

        Assertions.assertNotNull(origins);

        Assertions.assertFalse(origins.isEmpty());

        Assertions.assertNotNull(config.getAllowedMethods());

        Assertions.assertEquals(
                5,
                config.getAllowedMethods().size()
        );

        Assertions.assertTrue(
                config.getAllowedMethods().contains("GET")
        );

        Assertions.assertTrue(
                config.getAllowedMethods().contains("POST")
        );

        Assertions.assertTrue(
                config.getAllowedMethods().contains("PUT")
        );

        Assertions.assertTrue(
                config.getAllowedMethods().contains("DELETE")
        );

        Assertions.assertTrue(
                config.getAllowedMethods().contains("OPTIONS")
        );

        Assertions.assertNotNull(config.getAllowedHeaders());

        Assertions.assertTrue(
                config.getAllowedHeaders().contains("*")
        );
    }

    // =========================================================
    // SECURITY CONFIG
    // =========================================================

    @Test
    void deveCarregarSecurityConfig() {

        Assertions.assertNotNull(securityConfig);
    }

    @Test
    void devePermitirEndpointPublico() throws Exception {

        mockMvc.perform(get("/api/auth/test"))
                .andExpect(result -> {

                    int status = result.getResponse().getStatus();

                    Assertions.assertTrue(
                            status == 200 || status == 404
                    );
                });
    }

    @Test
    void deveResponderEndpointTeste() throws Exception {

        mockMvc.perform(get("/teste"))
                .andExpect(status().isOk());
    }

    // =========================================================
    // CONTROLLER MOCK
    // =========================================================

    @RestController
    static class TestController {

        @GetMapping("/teste")
        public String teste() {
            return "ok";
        }
    }
}