package acc.br.nextpay;

import acc.br.nextpay.controller.CarteiraController;
import acc.br.nextpay.dto.CarteiraRequest;
import acc.br.nextpay.model.ContaCorrente;
import acc.br.nextpay.service.TransacaoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.util.Map;

import static org.mockito.Mockito.*;

class CarteiraControllerTest {

    @InjectMocks
    private CarteiraController carteiraController;

    @Mock
    private TransacaoService transacaoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Helper para mockar o SecurityContextHolder que o controller usa
     */
    private void mockAutenticacao(Long usuarioId, MockedStatic<SecurityContextHolder> mockedSecurity) {
        SecurityContext securityContext = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);

        mockedSecurity.when(SecurityContextHolder::getContext).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(usuarioId);
    }

    @Test
    void deveRetornarSaldoComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            // Preparação
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            ContaCorrente contaMock = ContaCorrente.builder().saldo(BigDecimal.TEN).build();
            when(transacaoService.buscarContaPorUsuario(usuarioId)).thenReturn(contaMock);

            // Execução
            ResponseEntity<ContaCorrente> response = carteiraController.saldo();

            // Verificação
            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals(BigDecimal.TEN, response.getBody().getSaldo());
        }
    }

    @Test
    void deveRealizarDepositoComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            CarteiraRequest request = new CarteiraRequest();
            request.setValor(BigDecimal.valueOf(100));

            ContaCorrente contaAtualizada = ContaCorrente.builder().saldo(BigDecimal.valueOf(100)).build();
            when(transacaoService.depositar(eq(usuarioId), any(BigDecimal.class))).thenReturn(contaAtualizada);

            ResponseEntity<ContaCorrente> response = carteiraController.depositar(request);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals(BigDecimal.valueOf(100), response.getBody().getSaldo());
        }
    }

    @Test
    void deveRealizarPixComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            CarteiraRequest request = new CarteiraRequest();
            request.setChavePix("teste@pix.com");
            request.setValor(BigDecimal.valueOf(50));

            when(transacaoService.pix(eq(usuarioId), eq("teste@pix.com"), any(BigDecimal.class)))
                    .thenReturn("PIX realizado com sucesso.");

            ResponseEntity<Map<String, String>> response = carteiraController.pix(request);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("PIX realizado com sucesso.", response.getBody().get("mensagem"));
        }
    }
}