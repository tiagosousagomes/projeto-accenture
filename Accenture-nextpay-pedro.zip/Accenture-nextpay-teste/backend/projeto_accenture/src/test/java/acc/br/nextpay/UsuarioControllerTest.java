package acc.br.nextpay;

import acc.br.nextpay.controller.UsuarioController;
import acc.br.nextpay.dto.ConfirmacaoEmailDTO;
import acc.br.nextpay.model.Usuario;
import acc.br.nextpay.service.UsuarioService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Map;
import java.util.Optional;

import static org.mockito.Mockito.*;

class UsuarioControllerTest {

    @InjectMocks
    private UsuarioController usuarioController;

    @Mock
    private UsuarioService usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Helper para mockar o SecurityContextHolder (necessário para Delete e Put)
     */
    private void mockAutenticacao(Long usuarioId, MockedStatic<SecurityContextHolder> mockedSecurity) {
        SecurityContext securityContext = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);

        mockedSecurity.when(SecurityContextHolder::getContext).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(usuarioId);
    }

    @Test
    void deveCadastrarUsuarioComSucesso() {
        // Preparação
        Usuario usuario = new Usuario();
        usuario.setNome("Pedro");
        usuario.setEmail("pedro@email.com");

        when(usuarioService.cadastrarUsuario(any(Usuario.class), eq("12345678"), eq("10")))
                .thenReturn(usuario);

        // Execução
        var response = usuarioController.cadastrar(usuario, "12345678", "10");

        // Verificação
        Assertions.assertEquals(201, response.getStatusCodeValue());
        Assertions.assertNotNull(response.getBody());
        verify(usuarioService, times(1)).cadastrarUsuario(any(), anyString(), anyString());
    }

    @Test
    void deveConfirmarEmailComSucesso() {
        ConfirmacaoEmailDTO dto = new ConfirmacaoEmailDTO();
        dto.setEmail("teste@email.com");
        dto.setCodigo("123456");

        doNothing().when(usuarioService).confirmarCodigoEmail(anyString(), anyString());

        ResponseEntity<String> response = usuarioController.confirmarEmail(dto);

        Assertions.assertEquals(200, response.getStatusCodeValue());
        Assertions.assertEquals("Cadastro realizado com sucesso.", response.getBody());
    }

    @Test
    void deveExcluirContaComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long idParaExcluir = 1L;
            mockAutenticacao(idParaExcluir, mockedSecurity); // Simula que o usuário logado é o dono da conta

            doNothing().when(usuarioService).excluirConta(eq(idParaExcluir), eq(idParaExcluir));

            ResponseEntity<Map<String, String>> response = usuarioController.excluirConta(idParaExcluir);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("Conta excluída com sucesso.", response.getBody().get("mensagem"));
            verify(usuarioService).excluirConta(idParaExcluir, idParaExcluir);
        }
    }

    @Test
    void deveBuscarUsuarioPorIdComSucesso() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("Joao");

        when(usuarioService.buscarPorId(1L)).thenReturn(usuario);

        var response = usuarioController.buscarPorId(1L);

        Assertions.assertEquals(200, response.getStatusCodeValue());
        Assertions.assertEquals("Joao", response.getBody().getNome());
    }
}