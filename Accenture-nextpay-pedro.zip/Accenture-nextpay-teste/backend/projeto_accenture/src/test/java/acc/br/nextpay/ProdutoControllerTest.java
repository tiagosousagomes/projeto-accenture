package acc.br.nextpay;

import acc.br.nextpay.controller.ProdutoController;
import acc.br.nextpay.model.Produto;
import acc.br.nextpay.service.ProdutoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;

class ProdutoControllerTest {

    @InjectMocks
    private ProdutoController produtoController;

    @Mock
    private ProdutoService produtoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Helper para mockar o SecurityContextHolder
     */
    private void mockAutenticacao(Long usuarioId, MockedStatic<SecurityContextHolder> mockedSecurity) {
        SecurityContext securityContext = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);

        mockedSecurity.when(SecurityContextHolder::getContext).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(usuarioId);
    }

    @Test
    void deveCadastrarProdutoComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            Produto produto = new Produto();
            produto.setNome("Teclado");

            when(produtoService.cadastrarProduto(any(Produto.class), eq(usuarioId))).thenReturn(produto);

            ResponseEntity<Produto> response = produtoController.cadastrar(produto);

            Assertions.assertEquals(201, response.getStatusCodeValue());
            Assertions.assertEquals("Teclado", response.getBody().getNome());
        }
    }

    @Test
    void deveListarTodosOsProdutosComEstoque() {
        Produto p1 = new Produto();
        p1.setNome("Produto A");
        when(produtoService.listarProdutosComEstoque()).thenReturn(List.of(p1));

        ResponseEntity<List<Produto>> response = produtoController.listarTodos();

        Assertions.assertEquals(200, response.getStatusCodeValue());
        Assertions.assertEquals(1, response.getBody().size());
        verify(produtoService, times(1)).listarProdutosComEstoque();
    }

    @Test
    void deveListarMeusProdutosComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            when(produtoService.listarProdutosDoUsuario(usuarioId)).thenReturn(List.of(new Produto()));

            ResponseEntity<List<Produto>> response = produtoController.listarMeusProdutos();

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertFalse(response.getBody().isEmpty());
        }
    }

    @Test
    void deveExcluirProdutoComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            Long produtoId = 100L;
            mockAutenticacao(usuarioId, mockedSecurity);

            doNothing().when(produtoService).excluirProduto(produtoId, usuarioId);

            ResponseEntity<Map<String, String>> response = produtoController.excluir(produtoId);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("Produto desativado com sucesso.", response.getBody().get("mensagem"));
            verify(produtoService).excluirProduto(produtoId, usuarioId);
        }
    }
}