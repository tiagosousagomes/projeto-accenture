package acc.br.nextpay.ai;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.List;

class DocumentChunkTest {

    @Test
    void deveCriarDocumentChunkCorretamente() {
        // Preparação
        String texto = "Conteúdo de teste para IA";
        List<Float> vetores = List.of(0.1f, 0.2f, 0.3f);

        // Execução
        DocumentChunk chunk = new DocumentChunk(texto, vetores);

        // Verificação
        Assertions.assertEquals(texto, chunk.content());
        Assertions.assertEquals(vetores, chunk.embedding());
        Assertions.assertEquals(3, chunk.embedding().size());
    }
}