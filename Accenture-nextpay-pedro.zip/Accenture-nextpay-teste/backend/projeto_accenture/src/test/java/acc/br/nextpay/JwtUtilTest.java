package acc.br.nextpay;

import acc.br.nextpay.security.JwtUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.charset.StandardCharsets;

class JwtUtilTest {

    private JwtUtil jwtUtil;

    // Chave precisa ter pelo menos 32 caracteres para HS256
    private final String SECRET =
            "minha-chave-secreta-super-segura-123456";

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil();

        ReflectionTestUtils.setField(jwtUtil, "secret", SECRET);
        ReflectionTestUtils.setField(jwtUtil, "expiration", 3600000L);
    }

    @Test
    void deveGerarTokenComSucesso() {
        String token = jwtUtil.gerarToken(1L, "teste@email.com");

        Assertions.assertNotNull(token);
        Assertions.assertFalse(token.isBlank());
    }

    @Test
    void deveExtrairUsuarioIdCorretamente() {
        String token = jwtUtil.gerarToken(10L, "user@email.com");

        Long usuarioId = jwtUtil.extrairUsuarioId(token);

        Assertions.assertEquals(10L, usuarioId);
    }

    @Test
    void deveValidarTokenValido() {
        String token = jwtUtil.gerarToken(5L, "teste@email.com");

        boolean valido = jwtUtil.validarToken(token);

        Assertions.assertTrue(valido);
    }

    @Test
    void deveRetornarFalseParaTokenInvalido() {
        String tokenInvalido = "token.invalido.aqui";

        boolean valido = jwtUtil.validarToken(tokenInvalido);

        Assertions.assertFalse(valido);
    }

    @Test
    void deveRetornarFalseParaTokenAlterado() {
        String token = jwtUtil.gerarToken(1L, "teste@email.com");

        // altera o token
        token = token + "abc";

        boolean valido = jwtUtil.validarToken(token);

        Assertions.assertFalse(valido);
    }

    @Test
    void deveConterEmailNoPayload() {
        String email = "usuario@email.com";

        String token = jwtUtil.gerarToken(99L, email);

        Claims claims = Jwts.parser()
                .verifyWith(
                        io.jsonwebtoken.security.Keys.hmacShaKeyFor(
                                SECRET.getBytes(StandardCharsets.UTF_8)
                        )
                )
                .build()
                .parseSignedClaims(token)
                .getPayload();

        Assertions.assertEquals(email, claims.get("email"));
    }

    @Test
    void deveGerarTokenComSubjectCorreto() {
        String token = jwtUtil.gerarToken(123L, "abc@email.com");

        Claims claims = Jwts.parser()
                .verifyWith(
                        io.jsonwebtoken.security.Keys.hmacShaKeyFor(
                                SECRET.getBytes(StandardCharsets.UTF_8)
                        )
                )
                .build()
                .parseSignedClaims(token)
                .getPayload();

        Assertions.assertEquals("123", claims.getSubject());
    }

    @Test
    void deveGerarTokenComDataExpiracao() {
        String token = jwtUtil.gerarToken(1L, "teste@email.com");

        Claims claims = Jwts.parser()
                .verifyWith(
                        io.jsonwebtoken.security.Keys.hmacShaKeyFor(
                                SECRET.getBytes(StandardCharsets.UTF_8)
                        )
                )
                .build()
                .parseSignedClaims(token)
                .getPayload();

        Assertions.assertNotNull(claims.getExpiration());
    }

    @Test
    void deveFalharAoExtrairUsuarioDeTokenInvalido() {
        Assertions.assertThrows(Exception.class, () -> {
            jwtUtil.extrairUsuarioId("token.invalido");
        });
    }
}