package acc.br.nextpay;

import acc.br.nextpay.ai.AssistenteRegrasNegocio;
import acc.br.nextpay.controller.AjudaController;
import acc.br.nextpay.security.JwtFilter;
import acc.br.nextpay.security.JwtUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(
        controllers = AjudaController.class,
        excludeAutoConfiguration = {
                SecurityAutoConfiguration.class
        },
        excludeFilters = {
                @ComponentScan.Filter(
                        type = FilterType.ASSIGNABLE_TYPE,
                        classes = JwtFilter.class
                )
        }
)
@AutoConfigureMockMvc(addFilters = false)
class AjudaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AssistenteRegrasNegocio assistenteRegrasNegocio;

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private JwtFilter jwtFilter;

    @Test
    void deveResponderPerguntaComSucesso() throws Exception {

        when(assistenteRegrasNegocio.perguntar("Como funciona o PIX?"))
                .thenReturn("PIX funciona instantaneamente.");

        String json = """
                {
                    "pergunta": "Como funciona o PIX?"
                }
                """;

        mockMvc.perform(post("/api/ajuda/perguntar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resposta")
                        .value("PIX funciona instantaneamente."));
    }

    @Test
    void deveChamarAssistenteRegrasNegocio() throws Exception {

        when(assistenteRegrasNegocio.perguntar(anyString()))
                .thenReturn("Resposta IA");

        String json = """
                {
                    "pergunta": "Teste IA"
                }
                """;

        mockMvc.perform(post("/api/ajuda/perguntar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk());

        verify(assistenteRegrasNegocio, times(1))
                .perguntar("Teste IA");
    }

    @Test
    void deveRetornarJsonComCampoResposta() throws Exception {

        when(assistenteRegrasNegocio.perguntar(anyString()))
                .thenReturn("Resposta teste");

        String json = """
                {
                    "pergunta": "Pergunta teste"
                }
                """;

        mockMvc.perform(post("/api/ajuda/perguntar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resposta").exists());
    }

    @Test
    void deveAceitarPerguntaVazia() throws Exception {

        when(assistenteRegrasNegocio.perguntar(""))
                .thenReturn("Pergunta vazia");

        String json = """
                {
                    "pergunta": ""
                }
                """;

        mockMvc.perform(post("/api/ajuda/perguntar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resposta")
                        .value("Pergunta vazia"));
    }

    @Test
    void deveRetornarErroQuandoBodyForInvalido() throws Exception {

        String json = """
                {
                    "campoErrado": "teste"
                }
                """;

        when(assistenteRegrasNegocio.perguntar(null))
                .thenReturn("Resposta padrão");

        mockMvc.perform(post("/api/ajuda/perguntar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk());
    }
}