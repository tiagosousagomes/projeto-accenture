package acc.br.nextpay;

import acc.br.nextpay.security.JwtFilter;
import acc.br.nextpay.security.JwtUtil;
import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;

class JwtFilterTest {

    private JwtUtil jwtUtil;
    private JwtFilter jwtFilter;
    private FilterChain filterChain;

    @BeforeEach
    void setUp() {
        jwtUtil = Mockito.mock(JwtUtil.class);
        jwtFilter = new JwtFilter(jwtUtil);
        filterChain = Mockito.mock(FilterChain.class);

        SecurityContextHolder.clearContext();
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void deveAutenticarUsuarioQuandoTokenForValido() throws Exception {

        String token = "token-valido";

        Mockito.when(jwtUtil.validarToken(token))
                .thenReturn(true);

        Mockito.when(jwtUtil.extrairUsuarioId(token))
                .thenReturn(1L);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Object principal = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        Assertions.assertEquals(1L, principal);

        Mockito.verify(filterChain)
                .doFilter(request, response);
    }

    @Test
    void naoDeveAutenticarQuandoTokenForInvalido() throws Exception {

        String token = "token-invalido";

        Mockito.when(jwtUtil.validarToken(token))
                .thenReturn(false);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Assertions.assertNull(
                SecurityContextHolder.getContext().getAuthentication()
        );

        Mockito.verify(filterChain)
                .doFilter(request, response);
    }

    @Test
    void naoDeveAutenticarQuandoHeaderAuthorizationForNulo() throws Exception {

        MockHttpServletRequest request = new MockHttpServletRequest();

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Assertions.assertNull(
                SecurityContextHolder.getContext().getAuthentication()
        );

        Mockito.verify(filterChain)
                .doFilter(request, response);
    }

    @Test
    void naoDeveAutenticarQuandoHeaderNaoComecarComBearer() throws Exception {

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Basic abc123");

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Assertions.assertNull(
                SecurityContextHolder.getContext().getAuthentication()
        );

        Mockito.verify(filterChain)
                .doFilter(request, response);
    }

    @Test
    void deveChamarValidarTokenQuandoBearerExistir() throws Exception {

        String token = "meu-token";

        Mockito.when(jwtUtil.validarToken(token))
                .thenReturn(false);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Mockito.verify(jwtUtil)
                .validarToken(token);
    }

    @Test
    void deveChamarExtrairUsuarioIdQuandoTokenForValido() throws Exception {

        String token = "token-ok";

        Mockito.when(jwtUtil.validarToken(token))
                .thenReturn(true);

        Mockito.when(jwtUtil.extrairUsuarioId(token))
                .thenReturn(99L);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        Mockito.verify(jwtUtil)
                .extrairUsuarioId(token);
    }

    @Test
    void deveCriarAuthenticationComUsuarioIdCorreto() throws Exception {

        String token = "token-auth";

        Mockito.when(jwtUtil.validarToken(token))
                .thenReturn(true);

        Mockito.when(jwtUtil.extrairUsuarioId(token))
                .thenReturn(777L);

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + token);

        MockHttpServletResponse response = new MockHttpServletResponse();

        jwtFilter.doFilter(request, response, filterChain);

        var authentication = SecurityContextHolder
                .getContext()
                .getAuthentication();

        Assertions.assertNotNull(authentication);
        Assertions.assertEquals(777L, authentication.getPrincipal());
        Assertions.assertTrue(authentication.getAuthorities().isEmpty());
    }
}