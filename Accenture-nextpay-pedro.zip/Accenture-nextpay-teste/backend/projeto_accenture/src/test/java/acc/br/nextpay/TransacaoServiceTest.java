package acc.br.nextpay;

import acc.br.nextpay.exception.NegocioException;
import acc.br.nextpay.exception.SaldoInsuficienteException;
import acc.br.nextpay.model.ContaCorrente;
import acc.br.nextpay.model.Transacao;
import acc.br.nextpay.model.Usuario;
import acc.br.nextpay.model.enums.TipoTransacao;
import acc.br.nextpay.repository.ContaCorrenteRepository;
import acc.br.nextpay.repository.TransacaoRepository;
import acc.br.nextpay.repository.UsuarioRepository;
import acc.br.nextpay.service.TransacaoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class TransacaoServiceTest {

    @InjectMocks
    private TransacaoService transacaoService;

    @Mock private UsuarioRepository usuarioRepository;
    @Mock private ContaCorrenteRepository contaCorrenteRepository;
    @Mock private TransacaoRepository transacaoRepository;

    private Usuario usuarioOrigem;
    private Usuario usuarioDestino;
    private ContaCorrente contaOrigem;
    private ContaCorrente contaDestino;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Configuração Origem
        contaOrigem = ContaCorrente.builder()
                .id(1L)
                .saldo(new BigDecimal("500.00"))
                .build();

        usuarioOrigem = new Usuario();
        usuarioOrigem.setId(1L);
        usuarioOrigem.setNome("Origem");
        usuarioOrigem.setConta(contaOrigem);

        // Configuração Destino
        contaDestino = ContaCorrente.builder()
                .id(2L)
                .saldo(new BigDecimal("100.00"))
                .build();

        usuarioDestino = new Usuario();
        usuarioDestino.setId(2L);
        usuarioDestino.setNome("Destino");
        usuarioDestino.setConta(contaDestino);
    }

    @Test
    void deveDepositarComSucesso() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOrigem));
        when(contaCorrenteRepository.findByIdWithLock(1L)).thenReturn(Optional.of(contaOrigem));

        transacaoService.depositar(1L, new BigDecimal("100.00"));

        Assertions.assertEquals(new BigDecimal("600.00"), contaOrigem.getSaldo());
        verify(transacaoRepository, times(1)).save(any(Transacao.class));
    }

    @Test
    void deveSacarComSucesso() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOrigem));
        when(contaCorrenteRepository.findByIdWithLock(1L)).thenReturn(Optional.of(contaOrigem));

        transacaoService.sacar(1L, new BigDecimal("200.00"));

        Assertions.assertEquals(new BigDecimal("300.00"), contaOrigem.getSaldo());
    }

    @Test
    void deveLancarErroAoSacarSemSaldo() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOrigem));
        when(contaCorrenteRepository.findByIdWithLock(1L)).thenReturn(Optional.of(contaOrigem));

        Assertions.assertThrows(SaldoInsuficienteException.class, () -> {
            transacaoService.sacar(1L, new BigDecimal("1000.00"));
        });
    }

    @Test
    void deveRealizarTransferenciaComSucesso() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOrigem));
        when(usuarioRepository.findById(2L)).thenReturn(Optional.of(usuarioDestino));

        // Simula os locks na ordem crescente de ID (1 e depois 2)
        when(contaCorrenteRepository.findByIdWithLock(1L)).thenReturn(Optional.of(contaOrigem));
        when(contaCorrenteRepository.findByIdWithLock(2L)).thenReturn(Optional.of(contaDestino));

        String resultado = transacaoService.transferir(1L, 2L, new BigDecimal("100.00"));

        Assertions.assertEquals("Transferência realizada com sucesso.", resultado);
        Assertions.assertEquals(new BigDecimal("400.00"), contaOrigem.getSaldo());
        Assertions.assertEquals(new BigDecimal("200.00"), contaDestino.getSaldo());

        // Verifica se registrou 2 transações (uma para cada usuário)
        verify(transacaoRepository, times(2)).save(any(Transacao.class));
    }

    @Test
    void deveLancarErroAoTransferirParaSiMesmo() {
        Assertions.assertThrows(NegocioException.class, () -> {
            transacaoService.transferir(1L, 1L, new BigDecimal("50.00"));
        });
    }

    @Test
    void deveRealizarPixPorChaveComSucesso() {
        String chave = "destino@email.com";
        usuarioDestino.setEmail(chave);

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioOrigem));
        when(usuarioRepository.findByEmail(chave)).thenReturn(Optional.of(usuarioDestino));

        when(contaCorrenteRepository.findByIdWithLock(1L)).thenReturn(Optional.of(contaOrigem));
        when(contaCorrenteRepository.findByIdWithLock(2L)).thenReturn(Optional.of(contaDestino));

        transacaoService.pix(1L, chave, new BigDecimal("50.00"));

        Assertions.assertEquals(new BigDecimal("450.00"), contaOrigem.getSaldo());
        Assertions.assertEquals(new BigDecimal("150.00"), contaDestino.getSaldo());
    }

    @Test
    void deveValidarValorNegativo() {
        Assertions.assertThrows(NegocioException.class, () -> {
            transacaoService.depositar(1L, new BigDecimal("-10.00"));
        });
    }
}