package acc.br.nextpay;

import acc.br.nextpay.exception.NegocioException;
import acc.br.nextpay.exception.RecursoNaoEncontradoException;
import acc.br.nextpay.model.Produto;
import acc.br.nextpay.model.Usuario;
import acc.br.nextpay.repository.ProdutoRepository;
import acc.br.nextpay.repository.UsuarioRepository;
import acc.br.nextpay.service.ProdutoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ProdutoServiceTest {

    @InjectMocks
    private ProdutoService produtoService;

    @Mock
    private ProdutoRepository produtoRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    private Usuario vendedor;
    private Produto produtoExistente;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        vendedor = new Usuario();
        vendedor.setId(10L);
        vendedor.setNome("Vendedor Teste");

        produtoExistente = new Produto();
        produtoExistente.setId(1L);
        produtoExistente.setNome("Produto Original");
        produtoExistente.setVendedor(vendedor);
        produtoExistente.setQuantidadeEstoque(5);
        produtoExistente.setAtivo(true);
    }

    @Test
    void deveCadastrarProdutoComSucesso() {
        when(usuarioRepository.findById(10L)).thenReturn(Optional.of(vendedor));
        when(produtoRepository.save(any(Produto.class))).thenAnswer(i -> i.getArgument(0));

        Produto novo = new Produto();
        novo.setNome("Novo Produto");

        Produto resultado = produtoService.cadastrarProduto(novo, 10L);

        Assertions.assertNotNull(resultado);
        Assertions.assertEquals("Novo Produto", resultado.getNome());
        Assertions.assertEquals(vendedor, resultado.getVendedor());
        verify(produtoRepository, times(1)).save(novo);
    }

    @Test
    void deveEditarProdutoProprioComSucesso() {
        when(produtoRepository.findById(1L)).thenReturn(Optional.of(produtoExistente));
        when(produtoRepository.saveAndFlush(any(Produto.class))).thenAnswer(i -> i.getArgument(0));

        Produto dadosNovos = new Produto();
        dadosNovos.setNome("Produto Atualizado");
        dadosNovos.setPreco(new BigDecimal("99.90"));
        dadosNovos.setQuantidadeEstoque(20);

        Produto resultado = produtoService.editarProduto(1L, 10L, dadosNovos);

        Assertions.assertEquals("Produto Atualizado", resultado.getNome());
        Assertions.assertEquals(20, resultado.getQuantidadeEstoque());
        verify(produtoRepository).saveAndFlush(any(Produto.class));
    }

    @Test
    void deveLancarExcecaoAoEditarProdutoDeOutroUsuario() {
        when(produtoRepository.findById(1L)).thenReturn(Optional.of(produtoExistente));

        Produto dadosNovos = new Produto();

        // Tentando editar com o ID de usuário 99 (o dono é 10)
        Assertions.assertThrows(NegocioException.class, () -> {
            produtoService.editarProduto(1L, 99L, dadosNovos);
        });
    }

    @Test
    void deveExcluirLogicamenteOProduto() {
        when(produtoRepository.findById(1L)).thenReturn(Optional.of(produtoExistente));

        produtoService.excluirProduto(1L, 10L);

        // Verifica se o setAtivo(false) foi chamado antes do save
        Assertions.assertFalse(produtoExistente.isAtivo());
        verify(produtoRepository).save(produtoExistente);
    }

    @Test
    void deveLancarErroAoBuscarProdutoInexistente() {
        when(produtoRepository.findById(anyLong())).thenReturn(Optional.empty());

        Assertions.assertThrows(RecursoNaoEncontradoException.class, () -> {
            produtoService.excluirProduto(1L, 10L);
        });
    }
}