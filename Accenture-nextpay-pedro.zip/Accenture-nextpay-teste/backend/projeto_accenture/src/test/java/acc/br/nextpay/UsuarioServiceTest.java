package acc.br.nextpay;

import acc.br.nextpay.exception.NegocioException;
import acc.br.nextpay.model.Endereco;
import acc.br.nextpay.model.Usuario;
import acc.br.nextpay.repository.UsuarioRepository;
import acc.br.nextpay.service.EmailService;
import acc.br.nextpay.service.UsuarioService;
import acc.br.nextpay.service.ViaCepService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class UsuarioServiceTest {

    @InjectMocks
    private UsuarioService usuarioService;

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private ViaCepService viaCepService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private EmailService emailService;

    private Usuario usuarioExemplo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        usuarioExemplo = new Usuario();
        usuarioExemplo.setId(1L);
        usuarioExemplo.setNome("Teste Usuario");
        usuarioExemplo.setEmail("teste@nextpay.com");
        usuarioExemplo.setSenha("senha123");
        usuarioExemplo.setCpfCnpj("12345678901");
    }

    @Test
    void deveCadastrarUsuarioComSucesso() {

        when(usuarioRepository.existsByEmail(anyString())).thenReturn(false);
        when(usuarioRepository.existsByCpfCnpj(anyString())).thenReturn(false);

        when(passwordEncoder.encode(anyString()))
                .thenReturn("senha_criptografada");

        Endereco enderecoMock = new Endereco();
        enderecoMock.setLogradouro("Rua Teste");

        when(viaCepService.buscarEnderecoPorCep("12345678"))
                .thenReturn(enderecoMock);

        when(usuarioRepository.save(any(Usuario.class)))
                .thenAnswer(i -> i.getArgument(0));

        Usuario resultado =
                usuarioService.cadastrarUsuario(
                        usuarioExemplo,
                        "12345678",
                        "100"
                );

        Assertions.assertNotNull(resultado);
        Assertions.assertEquals(
                "senha_criptografada",
                resultado.getSenha()
        );

        Assertions.assertNotNull(resultado.getConta());

        Assertions.assertNotNull(
                resultado.getTokenConfirmacao()
        );

        Assertions.assertFalse(resultado.isEmailConfirmado());

        Assertions.assertEquals(
                "100",
                resultado.getEndereco().getNumero()
        );

        verify(emailService, times(1))
                .enviarEmail(
                        eq("teste@nextpay.com"),
                        anyString(),
                        anyString()
                );
    }

    @Test
    void deveLancarErroSeEmailJaExistir() {

        when(usuarioRepository.existsByEmail(
                "teste@nextpay.com"
        )).thenReturn(true);

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.cadastrarUsuario(
                        usuarioExemplo,
                        "12345678",
                        "10"
                )
        );
    }

    @Test
    void deveLancarErroSeCpfJaExistir() {

        when(usuarioRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(usuarioRepository.existsByCpfCnpj(anyString()))
                .thenReturn(true);

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.cadastrarUsuario(
                        usuarioExemplo,
                        "12345678",
                        "10"
                )
        );
    }

    @Test
    void deveCadastrarUsuarioMesmoSemEndereco() {

        when(usuarioRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(usuarioRepository.existsByCpfCnpj(anyString()))
                .thenReturn(false);

        when(passwordEncoder.encode(anyString()))
                .thenReturn("senha_criptografada");

        when(viaCepService.buscarEnderecoPorCep(anyString()))
                .thenReturn(null);

        when(usuarioRepository.save(any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Usuario resultado =
                usuarioService.cadastrarUsuario(
                        usuarioExemplo,
                        "12345678",
                        "10"
                );

        Assertions.assertNotNull(resultado);
        Assertions.assertNull(resultado.getEndereco());
    }

    @Test
    void deveCadastrarUsuarioMesmoComFalhaNoEmail() {

        when(usuarioRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(usuarioRepository.existsByCpfCnpj(anyString()))
                .thenReturn(false);

        when(passwordEncoder.encode(anyString()))
                .thenReturn("senha_criptografada");

        when(viaCepService.buscarEnderecoPorCep(anyString()))
                .thenReturn(new Endereco());

        when(usuarioRepository.save(any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        doThrow(new RuntimeException("Erro SMTP"))
                .when(emailService)
                .enviarEmail(anyString(), anyString(), anyString());

        Usuario resultado =
                usuarioService.cadastrarUsuario(
                        usuarioExemplo,
                        "12345678",
                        "10"
                );

        Assertions.assertNotNull(resultado);
    }

    @Test
    void deveConfirmarEmailComSucesso() {

        usuarioExemplo.setTokenConfirmacao("123456");
        usuarioExemplo.setEmailConfirmado(false);

        when(usuarioRepository.findByEmail(
                "teste@nextpay.com"
        )).thenReturn(Optional.of(usuarioExemplo));

        usuarioService.confirmarCodigoEmail(
                "teste@nextpay.com",
                "123456"
        );

        Assertions.assertTrue(
                usuarioExemplo.isEmailConfirmado()
        );

        Assertions.assertNull(
                usuarioExemplo.getTokenConfirmacao()
        );

        verify(usuarioRepository).save(usuarioExemplo);
    }

    @Test
    void deveLancarErroEmCodigoInvalido() {

        usuarioExemplo.setTokenConfirmacao("123456");

        when(usuarioRepository.findByEmail(
                "teste@nextpay.com"
        )).thenReturn(Optional.of(usuarioExemplo));

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.confirmarCodigoEmail(
                        "teste@nextpay.com",
                        "000000"
                )
        );
    }

    @Test
    void deveLancarErroQuandoEmailJaConfirmado() {

        usuarioExemplo.setEmailConfirmado(true);

        when(usuarioRepository.findByEmail(
                "teste@nextpay.com"
        )).thenReturn(Optional.of(usuarioExemplo));

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.confirmarCodigoEmail(
                        "teste@nextpay.com",
                        "123456"
                )
        );
    }

    @Test
    void deveLancarErroQuandoUsuarioNaoEncontradoAoConfirmarEmail() {

        when(usuarioRepository.findByEmail(anyString()))
                .thenReturn(Optional.empty());

        Assertions.assertThrows(
                Exception.class,
                () -> usuarioService.confirmarCodigoEmail(
                        "teste@nextpay.com",
                        "123456"
                )
        );
    }

    @Test
    void deveRealizarLoginComSucesso() {

        usuarioExemplo.setSenha("hash_no_banco");

        when(usuarioRepository.findByEmail(
                "teste@nextpay.com"
        )).thenReturn(Optional.of(usuarioExemplo));

        when(passwordEncoder.matches(
                "senha_digitada",
                "hash_no_banco"
        )).thenReturn(true);

        Usuario logado =
                usuarioService.login(
                        "teste@nextpay.com",
                        "senha_digitada"
                );

        Assertions.assertNotNull(logado);

        Assertions.assertEquals(
                "teste@nextpay.com",
                logado.getEmail()
        );
    }

    @Test
    void deveLancarErroNoLoginComSenhaInvalida() {

        usuarioExemplo.setSenha("hash_no_banco");

        when(usuarioRepository.findByEmail(
                "teste@nextpay.com"
        )).thenReturn(Optional.of(usuarioExemplo));

        when(passwordEncoder.matches(
                "senha_errada",
                "hash_no_banco"
        )).thenReturn(false);

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.login(
                        "teste@nextpay.com",
                        "senha_errada"
                )
        );
    }

    @Test
    void deveLancarErroQuandoUsuarioNaoExisteNoLogin() {

        when(usuarioRepository.findByEmail(anyString()))
                .thenReturn(Optional.empty());

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.login(
                        "teste@nextpay.com",
                        "123"
                )
        );
    }

    @Test
    void deveListarTodosUsuarios() {

        when(usuarioRepository.findAll())
                .thenReturn(List.of(usuarioExemplo));

        List<Usuario> lista =
                usuarioService.listarTodos();

        Assertions.assertEquals(1, lista.size());
    }

    @Test
    void deveBuscarUsuarioPorId() {

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuarioExemplo));

        Usuario usuario =
                usuarioService.buscarPorId(1L);

        Assertions.assertNotNull(usuario);
    }

    @Test
    void deveLancarErroAoBuscarUsuarioInexistente() {

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.empty());

        Assertions.assertThrows(
                Exception.class,
                () -> usuarioService.buscarPorId(1L)
        );
    }

    @Test
    void deveExcluirContaComSucesso() {

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuarioExemplo));

        usuarioService.excluirConta(1L, 1L);

        verify(usuarioRepository)
                .delete(usuarioExemplo);
    }

    @Test
    void deveLancarErroAoExcluirContaDeOutroUsuario() {

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.excluirConta(1L, 2L)
        );
    }

    @Test
    void deveAtualizarUsuarioComSucesso() {

        Usuario atualizado = new Usuario();
        atualizado.setNome("Novo Nome");
        atualizado.setFotoPerfil("foto.png");

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuarioExemplo));

        when(usuarioRepository.saveAndFlush(any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Usuario resultado =
                usuarioService.atualizarUsuario(
                        1L,
                        1L,
                        atualizado
                );

        Assertions.assertEquals(
                "Novo Nome",
                resultado.getNome()
        );

        Assertions.assertEquals(
                "foto.png",
                resultado.getFotoPerfil()
        );
    }

    @Test
    void deveAtualizarUsuarioSemFotoPerfil() {

        Usuario atualizado = new Usuario();
        atualizado.setNome("Nome Atualizado");

        usuarioExemplo.setFotoPerfil("foto_antiga.png");

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuarioExemplo));

        when(usuarioRepository.saveAndFlush(any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Usuario resultado =
                usuarioService.atualizarUsuario(
                        1L,
                        1L,
                        atualizado
                );

        Assertions.assertEquals(
                "Nome Atualizado",
                resultado.getNome()
        );

        Assertions.assertEquals(
                "foto_antiga.png",
                resultado.getFotoPerfil()
        );
    }

    @Test
    void deveLancarErroAoAtualizarOutroUsuario() {

        Usuario atualizado = new Usuario();

        Assertions.assertThrows(
                NegocioException.class,
                () -> usuarioService.atualizarUsuario(
                        1L,
                        2L,
                        atualizado
                )
        );
    }
}