package acc.br.nextpay;

import acc.br.nextpay.dto.PedidoDTO;
import acc.br.nextpay.exception.NegocioException;
import acc.br.nextpay.model.*;
import acc.br.nextpay.model.enums.StatusPedido;
import acc.br.nextpay.repository.*;
import acc.br.nextpay.service.PedidoService;
import acc.br.nextpay.service.TransacaoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PedidoServiceTest {

    @InjectMocks
    private PedidoService pedidoService;

    @Mock private PedidoRepository pedidoRepository;
    @Mock private ProdutoRepository produtoRepository;
    @Mock private UsuarioRepository usuarioRepository;
    @Mock private ContaCorrenteRepository contaCorrenteRepository;
    @Mock private TransacaoService transacaoService;

    private Usuario comprador;
    private Usuario vendedor;
    private Produto produto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // 1. Configurar Comprador
        comprador = new Usuario();
        comprador.setId(1L);
        comprador.setNome("João");
        comprador.setConta(ContaCorrente.builder().id(10L).saldo(new BigDecimal("1000.00")).build());

        // 2. Configurar Vendedor
        vendedor = new Usuario();
        vendedor.setId(2L);
        vendedor.setNome("Maria");
        vendedor.setConta(ContaCorrente.builder().id(20L).saldo(new BigDecimal("100.00")).build());

        // 3. Configurar Produto (AQUI ESTAVA O ERRO)
        produto = new Produto();
        produto.setId(100L);
        produto.setNome("Celular");
        produto.setPreco(new BigDecimal("500.00"));
        produto.setVendedor(vendedor);

        // FIX: Atribuindo valor ao campo que o log indicou estar nulo
        produto.setQuantidadeEstoque(10);
    }

    @Test
    void deveComprarProdutoComSucesso() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(comprador));
        when(produtoRepository.findById(100L)).thenReturn(Optional.of(produto));
        when(contaCorrenteRepository.findByIdWithLock(10L)).thenReturn(Optional.of(comprador.getConta()));
        when(contaCorrenteRepository.findByIdWithLock(20L)).thenReturn(Optional.of(vendedor.getConta()));

        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> {
            Pedido p = i.getArgument(0);
            p.setId(1L);
            return p;
        });

        PedidoDTO resultado = pedidoService.comprar(1L, 100L, 1);

        Assertions.assertNotNull(resultado);
        Assertions.assertEquals(StatusPedido.FINALIZADO.toString(), resultado.getStatus());
        // Se comprou 1 de 10, deve sobrar 9
        Assertions.assertFalse(produto.temEstoqueDisponivel(10));
    }

    @Test
    void deveReservarProdutoSemTransferirDinheiro() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(comprador));
        when(produtoRepository.findById(100L)).thenReturn(Optional.of(produto));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        PedidoDTO resultado = pedidoService.reservar(1L, 100L, 1);

        Assertions.assertEquals(StatusPedido.RESERVADO.toString(), resultado.getStatus());
        verify(produtoRepository, times(1)).save(produto);
    }
}