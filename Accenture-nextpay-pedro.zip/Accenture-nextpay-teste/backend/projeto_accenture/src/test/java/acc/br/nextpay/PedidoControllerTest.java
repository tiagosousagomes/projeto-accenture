package acc.br.nextpay;

import acc.br.nextpay.controller.PedidoController;
import acc.br.nextpay.dto.PedidoDTO;
import acc.br.nextpay.dto.PedidoRequest;
import acc.br.nextpay.service.PedidoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.mockito.Mockito.*;

class PedidoControllerTest {

    @InjectMocks
    private PedidoController pedidoController;

    @Mock
    private PedidoService pedidoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Helper para mockar o SecurityContextHolder
     */
    private void mockAutenticacao(Long usuarioId, MockedStatic<SecurityContextHolder> mockedSecurity) {
        SecurityContext securityContext = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);

        mockedSecurity.when(SecurityContextHolder::getContext).thenReturn(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(usuarioId);
    }

    @Test
    void deveComprarComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            // Preparação
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            PedidoRequest request = new PedidoRequest();
            request.setProdutoId(100L);
            request.setQuantidade(2);

            PedidoDTO dtoResponse = PedidoDTO.builder()
                    .id(50L)
                    .nomeProduto("Teclado")
                    .valorTotal(new BigDecimal("200.00"))
                    .status("FINALIZADO")
                    .build();

            when(pedidoService.comprar(usuarioId, 100L, 2)).thenReturn(dtoResponse);

            // Execução
            ResponseEntity<PedidoDTO> response = pedidoController.comprar(request);

            // Verificações
            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("FINALIZADO", response.getBody().getStatus());
            verify(pedidoService, times(1)).comprar(usuarioId, 100L, 2);
        }
    }

    @Test
    void deveReservarComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            mockAutenticacao(usuarioId, mockedSecurity);

            PedidoRequest request = new PedidoRequest();
            request.setProdutoId(101L);
            request.setQuantidade(1);

            PedidoDTO dtoResponse = PedidoDTO.builder()
                    .id(51L)
                    .status("RESERVADO")
                    .build();

            when(pedidoService.reservar(usuarioId, 101L, 1)).thenReturn(dtoResponse);

            ResponseEntity<PedidoDTO> response = pedidoController.reservar(request);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("RESERVADO", response.getBody().getStatus());
        }
    }

    @Test
    void deveConfirmarReservaComSucesso() {
        try (MockedStatic<SecurityContextHolder> mockedSecurity = mockStatic(SecurityContextHolder.class)) {
            Long usuarioId = 1L;
            Long pedidoId = 500L;
            mockAutenticacao(usuarioId, mockedSecurity);

            PedidoDTO dtoResponse = PedidoDTO.builder()
                    .id(pedidoId)
                    .status("FINALIZADO")
                    .build();

            when(pedidoService.confirmarReserva(pedidoId, usuarioId)).thenReturn(dtoResponse);

            ResponseEntity<PedidoDTO> response = pedidoController.confirmarReserva(pedidoId);

            Assertions.assertEquals(200, response.getStatusCodeValue());
            Assertions.assertEquals("FINALIZADO", response.getBody().getStatus());
            verify(pedidoService).confirmarReserva(pedidoId, usuarioId);
        }
    }
}