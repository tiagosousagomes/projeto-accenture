package acc.br.nextpay;

import acc.br.nextpay.controller.AuthController;
import acc.br.nextpay.dto.LoginRequest;
import acc.br.nextpay.model.Usuario;
import acc.br.nextpay.security.JwtUtil;
import acc.br.nextpay.service.UsuarioService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class AuthControllerTest {

    @InjectMocks
    private AuthController authController;

    @Mock
    private UsuarioService usuarioService;

    @Mock
    private JwtUtil jwtUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void deveRealizarLoginComSucessoERetornarToken() {
        // 1. Preparação (Mock dos dados de entrada)
        LoginRequest request = new LoginRequest();
        request.setEmail("usuario@teste.com");
        request.setSenha("senha123");

        // 2. Mock do Usuário retornado pelo Service
        Usuario usuarioMock = new Usuario();
        usuarioMock.setId(1L);
        usuarioMock.setNome("Usuario Teste");
        usuarioMock.setEmail("usuario@teste.com");

        // 3. Configuração dos comportamentos (Mocks)
        when(usuarioService.login("usuario@teste.com", "senha123")).thenReturn(usuarioMock);
        when(jwtUtil.gerarToken(1L, "usuario@teste.com")).thenReturn("mock-jwt-token");

        // 4. Execução
        ResponseEntity<Map<String, Object>> response = authController.login(request);

        // 5. Verificações
        Assertions.assertEquals(200, response.getStatusCodeValue());
        Assertions.assertNotNull(response.getBody());
        Assertions.assertEquals("mock-jwt-token", response.getBody().get("token"));
        Assertions.assertEquals(1L, response.getBody().get("usuarioId"));
        Assertions.assertEquals("Usuario Teste", response.getBody().get("nome"));

        // Garante que o service e o utilitário de JWT foram chamados
        verify(usuarioService, times(1)).login(anyString(), anyString());
        verify(jwtUtil, times(1)).gerarToken(anyLong(), anyString());
    }

    @Test
    void deveRetornarMensagemDeSucessoNoLogout() {
        // O logout em JWT no backend é conceitualmente simples (apenas resposta visual ou blacklist)
        ResponseEntity<Map<String, String>> response = authController.logout();

        Assertions.assertEquals(200, response.getStatusCodeValue());
        Assertions.assertEquals("Logout realizado com sucesso.", response.getBody().get("mensagem"));
    }
}